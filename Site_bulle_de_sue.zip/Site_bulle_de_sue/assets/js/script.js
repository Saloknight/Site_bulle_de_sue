let string = "Coucou ca va";
let number = -8;
number = 2.8;
let integer = 150;
let float = 12.9;
let boolean = true;
let objet = {};
const array = [];

let prenom= "Nicolas";
let nom = "Fréret"
let age = 40;

//console.log(`Bonjour ${prenom} ${nom} j'ai ${age + 1} ans`)

// let moi // OK
// const trtr // pas OK

// moi = "moi"


let num = 2,
num2 = 10

// console.log(num + num2)
// console.log(num - num2)
// console.log(num * num2)
// console.log(num / num2)
// console.log(num < num2)
// console.log(num > num2)
// console.log(num >= num2)
// console.log(num <= num2)
// console.log(num2 % 3)

let note = 9,
lock = undefined

// if( !!(lock) != false ){
//     console.log('kmlklkmlk')
// }

// if( !( !(note == 9 && !lock) || !(!lock) ) || lock ){
//     console.log('llllllllllllllllllllllll')
// }

// if( note == 9 || !lock ){
//     console.log('55555555555555555555555555555')
// }

// if(note == 15){
//     console.log(`coucou`)
// }else if(note > 10){
//     console.log(`tu gères`)
// }else{
//     console.log('lkllllllll')
// }

// if( note >= 18 ){
//     console.log(`tu gères`)
// }else if(note > 12){
//     console.log(`pas mal`)
// }else if( note >= 10){
//     console.log(`pas ouf`)
// }else{
//     console.log(`rattrapage`)
// }



// let 3sdsds= 'lklk'
// let variakble = "jljlj"
// const kshdkshds-sdsds = "ljlj"


let notes = [12,10,10,8,11];
const eleves = [
    {nom:'Fréret', prenom:'Nicolas', age:40, notes:[12,10,10,8,11]},
    {nom:'Durant', prenom:'Hélène', age:20,notes:[12,15,12,8,19]},
    {nom:'Deboisne', prenom:'Jules', age:17,notes:[20,19,17,5]}
];









let users = [
{
id: 1,
email: "john@mail.com",
password: "changeme",
name: "Jhon",
role: "customer",
avatar: "https://i.imgur.com/LDOO4Qs.jpg",
creationAt: "2025-11-19T22:27:11.000Z",
updatedAt: "2025-11-19T22:27:11.000Z"
},
{
id: 2,
email: "maria@mail.com",
password: "12345",
name: "Maria",
role: "customer",
avatar: "https://i.imgur.com/DTfowdu.jpg",
creationAt: "2025-11-19T22:27:11.000Z",
updatedAt: "2025-11-19T22:27:11.000Z"
},
{
id: 3,
email: "admin@mail.com",
password: "admin123",
name: "Admin",
role: "admin",
avatar: "https://i.imgur.com/yhW6Yw1.jpg",
creationAt: "2025-11-19T22:27:11.000Z",
updatedAt: "2025-11-19T22:27:11.000Z"
},
{
id: 38,
email: "ameya@gmail.com",
password: "ameya12",
name: "Ameya",
role: "customer",
avatar: "https://picsum.photos/800",
creationAt: "2025-11-20T05:21:53.000Z",
updatedAt: "2025-11-20T05:21:53.000Z"
},
{
id: 53,
email: "sai@gmail.com",
password: "venkat123",
name: "sai",
role: "customer",
avatar: "https://picsum.photos/800",
creationAt: "2025-11-20T06:50:05.000Z",
updatedAt: "2025-11-20T06:50:05.000Z"
},
{
id: 55,
email: "ameya@gmail.com",
password: "ameya12",
name: "Ameya Nimkar",
role: "customer",
avatar: "https://picsum.photos/800",
creationAt: "2025-11-20T06:51:31.000Z",
updatedAt: "2025-11-20T06:52:30.000Z"
},
{
id: 58,
email: "raj@gmail.com",
password: "12345678",
name: "raj",
role: "customer",
avatar: "https://i.imgur.com/LDOO4Qs.jpg",
creationAt: "2025-11-20T07:02:19.000Z",
updatedAt: "2025-11-20T07:02:19.000Z"
},
{
id: 61,
email: "hello@gmail.com",
password: "string",
name: "string",
role: "customer",
avatar: "https://th.bing.com/th/id/OIP.awAiMS1BCAQ2xS2lcdXGlwHaHH?w=203&h=196&c=7&r=0&o=7&pid=1.7&rm=3",
creationAt: "2025-11-20T07:32:15.000Z",
updatedAt: "2025-11-20T08:05:10.000Z"
},
{
id: 62,
email: "jhrn@gmail.com",
password: "string",
name: "jahran",
role: "admin",
avatar: "http://img.com/avatar.png",
creationAt: "2025-11-20T07:36:15.000Z",
updatedAt: "2025-11-20T07:40:46.000Z"
},
{
id: 64,
email: "huynf@gmail.com",
password: "123456789",
name: "huynf",
role: "customer",
avatar: "https://i.pravatar.cc/150?u=huynf",
creationAt: "2025-11-20T07:42:48.000Z",
updatedAt: "2025-11-20T07:42:48.000Z"
},
{
id: 65,
email: "mytestuser@example.com",
password: "Password123",
name: "My Test User",
role: "customer",
avatar: "https://i.pravatar.cc/150?img=8",
creationAt: "2025-11-20T07:46:34.000Z",
updatedAt: "2025-11-20T07:52:27.000Z"
},
{
id: 66,
email: "mazhar@email.com",
password: "dvsdfgeg",
name: "mazharoddin",
role: "customer",
avatar: "https://png.pngtree.com/png-clipart/20190516/original/pngtree-users-vector-icon-png-image_3725294.jpg",
creationAt: "2025-11-20T08:05:46.000Z",
updatedAt: "2025-11-20T08:05:46.000Z"
},
{
id: 67,
email: "abhinai@gmail.com",
password: "abcdef",
name: "abhinai",
role: "customer",
avatar: "https://i.imgur.com/LDOO4Qs.jpg",
creationAt: "2025-11-20T08:33:12.000Z",
updatedAt: "2025-11-20T08:33:12.000Z"
},
{
id: 68,
email: "dd@gmail.com",
password: "12345678",
name: "dd",
role: "customer",
avatar: "https://picsum.photos/800",
creationAt: "2025-11-20T08:48:11.000Z",
updatedAt: "2025-11-20T08:48:11.000Z"
},
{
id: 69,
email: "48940349089@gmail.com",
password: "2345809439043",
name: "vinay",
role: "customer",
avatar: "https://picsum.photos/800",
creationAt: "2025-11-20T08:54:25.000Z",
updatedAt: "2025-11-20T08:54:25.000Z"
},
{
id: 70,
email: "demo3@demo.ru",
password: "demo3",
name: "demo3",
role: "customer",
avatar: "https://avatar.iran.liara.run/public",
creationAt: "2025-11-20T09:13:09.000Z",
updatedAt: "2025-11-20T09:13:09.000Z"
},
{
id: 71,
email: "ncanh2806@gmail.com",
password: "ncanh2806",
name: "User KYC",
role: "customer",
avatar: "https://i.imgur.com/FPiPFrN.jpg",
creationAt: "2025-11-20T09:13:43.000Z",
updatedAt: "2025-11-20T09:13:43.000Z"
},
{
id: 72,
email: "kalab321@gmail.com",
password: "12345678",
name: "kalab1",
role: "customer",
avatar: "https://medium.com/@rafaelhhubner/monkey-d-luffy-as-a-captain-b3830d6413c5",
creationAt: "2025-11-20T09:13:48.000Z",
updatedAt: "2025-11-20T09:19:11.000Z"
},
{
id: 73,
email: "nnnn@gmail.com",
password: "ncanh2806",
name: "User KYC",
role: "customer",
avatar: "https://i.imgur.com/FPiPFrN.jpg",
creationAt: "2025-11-20T09:14:38.000Z",
updatedAt: "2025-11-20T09:14:38.000Z"
},
{
id: 77,
email: "test@gmail.com",
password: "123123",
name: "vinay",
role: "customer",
avatar: "https://picsum.photos/800",
creationAt: "2025-11-20T09:30:52.000Z",
updatedAt: "2025-11-20T09:30:52.000Z"
},
{
id: 78,
email: "ncanh2806@gmail.com",
password: "ncanh2806",
name: "User KYC",
role: "customer",
avatar: "https://i.imgur.com/FPiPFrN.jpg",
creationAt: "2025-11-20T09:35:52.000Z",
updatedAt: "2025-11-20T09:35:52.000Z"
},
{
id: 79,
email: "ncanh2806@gmail.com",
password: "ncanh2806",
name: "User KYC",
role: "customer",
avatar: "https://i.imgur.com/FPiPFrN.jpg",
creationAt: "2025-11-20T09:36:04.000Z",
updatedAt: "2025-11-20T09:36:04.000Z"
},
{
id: 80,
email: "ncanh2806@gmail.com",
password: "ncanh2806",
name: "User KYC",
role: "customer",
avatar: "https://i.imgur.com/FPiPFrN.jpg",
creationAt: "2025-11-20T09:39:07.000Z",
updatedAt: "2025-11-20T09:39:07.000Z"
},
{
id: 81,
email: "dg@gmail.com",
password: "12345678",
name: "dg",
role: "customer",
avatar: "https://i.sstatic.net/l60Hf.png",
creationAt: "2025-11-20T09:54:46.000Z",
updatedAt: "2025-11-20T09:54:46.000Z"
},
{
id: 82,
email: "nico@gmail.com",
password: "12345",
name: "Nicolas",
role: "customer",
avatar: "https://api.lorem.space/image/face?w=640&h=480",
creationAt: "2025-11-20T10:00:37.000Z",
updatedAt: "2025-11-20T10:00:37.000Z"
},
{
id: 83,
email: "nico@gmail.com",
password: "12345",
name: "Nicolas",
role: "customer",
avatar: "https://api.lorem.space/image/face?w=640&h=480",
creationAt: "2025-11-20T10:01:23.000Z",
updatedAt: "2025-11-20T10:01:23.000Z"
},
{
id: 84,
email: "test@gmail.com",
password: "123123",
name: "vinay",
role: "customer",
avatar: "https://picsum.photos/800",
creationAt: "2025-11-20T10:08:17.000Z",
updatedAt: "2025-11-20T10:08:17.000Z"
},
{
id: 85,
email: "2004sugarr@gmail.com",
password: "suga2004",
name: "umaa",
role: "customer",
avatar: "https://www.bing.com/ck/a?!&&p=26cb293661c12b00508ebb35e345ee630fa978d20eeb8005604a835f7e70a6a1JmltdHM9MTc2MzMzNzYwMA&ptn=3&ver=2&hsh=4&fclid=0cbc5522-241b-6753-34eb-434625646691&u=a1L2ltYWdlcy9zZWFyY2g_cT1zYW1wbGUrdWkraW1hZ2UmaWQ9NDc3MTExQzM0RTg2MUE1N0M0QzU0RDZFRENDRjc4MTFCQTI5MEJCQiZGT1JNPUlBQ0ZJUg",
creationAt: "2025-11-20T10:10:52.000Z",
updatedAt: "2025-11-20T10:10:52.000Z"
},
{
id: 87,
email: "m@gmail.com",
password: "man123",
name: "mango",
role: "customer",
avatar: "https://i.imgur.com/LDOO4Qs.jpg",
creationAt: "2025-11-20T10:19:43.000Z",
updatedAt: "2025-11-20T10:19:43.000Z"
},
{
id: 88,
email: "sy@gmail.com",
password: "Mybin123",
name: "sumit yadav",
role: "customer",
avatar: "https://i.imgur.com/LDOO4Qs.jpg",
creationAt: "2025-11-20T10:35:56.000Z",
updatedAt: "2025-11-20T10:35:56.000Z"
},
{
id: 89,
email: "tester123@mail.com",
password: "changeme123",
name: "Tester Viet Nam",
role: "customer",
avatar: "https://i.imgur.com/LDOO4Qs.jpg",
creationAt: "2025-11-20T10:36:31.000Z",
updatedAt: "2025-11-20T10:36:31.000Z"
},
{
id: 90,
email: "test@mail.com",
password: "changeme123",
name: "hahahah",
role: "customer",
avatar: "https://i.imgur.com/LDOO4Qs.jpg",
creationAt: "2025-11-20T10:36:31.000Z",
updatedAt: "2025-11-20T10:36:31.000Z"
},
{
id: 91,
email: "test@mail.com",
password: "changeme123",
name: "mdlfkdmslkfmldsfkmldsk",
role: "customer",
avatar: "https://i.imgur.com/LDOO4Qs.jpg",
creationAt: "2025-11-20T10:36:31.000Z",
updatedAt: "2025-11-20T10:36:31.000Z"
}
]

// const afficheMoi = _array => {

// }

/**
 * Sert à afficher toutes les propriété d'un tableau
 * 
 * @param {Array} _array Tableau à parcourir
 * @param {String} _prop Propriété à récupérer
 * @returns {void}
 */
function afficheMoi(_array = [],_prop){
    if(typeof(_array) !== 'object') return
    if(!_array.length) return

    for (let index = 0; index < _array.length; index++) {
         console.log(_array[index][_prop])
    }
}

//afficheMoi(users,'password')

eleves[1].notes[5] = 20
eleves[1].promo = 'B1'

const isPremium = true


// for (let i = 0; i < users.length ; i++) {
//     if( i !== 0) console.log(i, users[i].name)  
//     if(!isPremium) users[index].email = "Disponible en version payante";
// }


// for (let index = 0; index < users.length; index++) {
//     console.log(users[index].name)  
//     //if(!isPremium) users[index].email = "Disponible en version payante";
// }

// let index = 0
// while (index < users.length) {
//     console.log(users[index].name)
//     index++
// }


//console.log(users)

//console.log(users[ users.length - 1 ].name, users.length)

// let r = "mkmk"


// if (1==1){
//     let r2 = "coucou"
//     console.log(r,r2)

// }

//console.log(r,r2)


const header = document.querySelector('header')
const hbg = header.querySelector('.hbg')
const nav = header.querySelector('nav')

hbg.addEventListener('click', e=>{
    e.preventDefault()
    header.classList.toggle('open')
})


const a = document.createElement('a')
a.innerText = "Mon lien"
//a.setAttribute('href','https://www.mydigitalschool.com/')
a.href = "https://www.mydigitalschool.com/"
nav.append(a)

const liens = nav.querySelectorAll('a')
liens[1].innerText = "Prendre autre chose"
liens[4].innerText = "Contactez moi"

// let p = 0
// let interval = setInterval(()=>{
//     const m = p % 2 === 0 ? "Titre de ma page" : "Nouveau message..."
//     document.title = m
//     p++
//     if(p > 4) clearInterval(interval)
// },2000)

// saluer('Sam')
// saluer('Nicolas')
// saluer('Yohann')
// saluer('Atenea')
// saluer()


function repeat(_mot,_nbDeFois = 1){
    for (let index = 0; index < _nbDeFois; index++) {
        console.log(_mot+' '+index)   
    }
}

//repeat('bonjour',52)


const coucou2 = function(){
    console.log('je suis la function 2')
}

const coucou3 = (nom, age) => {console.log(`Salut ${nom}, tu as ${age} ans`)}


/**
 * Sert à saluer les gens
 * 
 * @param {?String} nom (optionnel) nom a saluer (par défaut 'Grand Maitre')
 * @returns {String}
 */
function saluer(nom = 'Grand Maitre'){
    return `Salut ${nom}`
    console.log('kkkkkkkkkkkk')
}

function saluer2(){
    const nom = prompt('Ton petit nom....')
    return `Salut ${nom}`
   
}


console.log(saluer('Lou'))

//coucou3('Jean', 25)
//coucou2()







    liens.forEach(function(lien,i){
        lien.innerText = `coucou ${i}`
        lien.href = "https://www.mydigitalschool.com/"
    })

    //document.querySelector('main').innerHTML = " coucou"


 function setChrono(_startTime = 10){
    let r = "mkmkmk"
    const header = document.querySelector('header'),
    logo = header.querySelector('.logo'),
    p = document.createElement('p')

    let i = _startTime
    p.id="monChrono"
    p.innerText = _startTime
    logo.style = 'text-align:center;font-weight:bold;'
    logo.innerHTML = ""
    logo.append('Temps Restant',p)
    

    let interval = setInterval(() => {

        p.innerText = i
        if(i <=  0){
            clearInterval(interval)
            alert('Fin du jeu')
        }
        i--
    }, 1000);


 }

 //setChrono(25)


console.log(liens)


// liens[0].addEventListener('click', e=>{
//      e.preventDefault()
//      alert('jai cliqué !')
// })

function removeActiveLink(){
    liens.forEach(function(a){
        a.classList.remove('active')
    })
}


liens.forEach(a=>{
    a.addEventListener('click', e=>{
        e.preventDefault()
        // console.log(e.pageX)
        //e.target.href = e.target.dataset.path
        removeActiveLink()
        e.target.classList.add('active')

    })
})

const cursor = document.querySelector('#cursor')

document.addEventListener('mousemove', e=>{
    cursor.style.left = e.clientX+'px'
    cursor.style.top = e.clientY+'px'

})


/**
 * Raccourci de querySelector
 * 
 * @param {String} _elems elements à sélectionner
 * @param {Null | HtmlElement} _parent Element dans lequel se trouve le/les éléments à selectionner
 * @returns 
 */
function get(_elems,_parent = null){
    const elems = _parent === null ? document.querySelectorAll(_elems) :
         _parent.querySelectorAll(_elems)

    if( elems.length === 1 ) return elems[0]
    return elems
}
    


//console.log(nav)

function sliderFading(_options = {}){

    const slider = document.querySelector('.slider-fading'),
    slides = slider.querySelectorAll('.slide'),
    options = {time:5,puces:false,autoplay:false,..._options}

    let index = 0,
    puces,
    timeout


    if(options.autoplay) autoplay()
    arrows()
    if(options.puces) setPuces()

    //console.log(puces)


    //Helpers

    function shiftSlide(_index){
        index = _index
        slides.forEach( (slide,i) =>{
            slide.classList.remove('visible')
            if(options.puces) puces[i].classList.remove('active')
        })
        if(slides.length - 1 < index) index = 0
        if(0 > index) index = slides.length - 1
        slides[index].classList.add('visible')
        puces[index].classList.add('active')
    }

    function autoplay(){
       timeout =  setTimeout(()=>{
            shiftSlide(++index)
            autoplay()
        }, options.time * 1000)
    }

    function pause(){
        if(!options.autoplay) return
        clearTimeout(timeout)
        autoplay()
    }



    function arrows(){
       const arrowsContainer = get('.arrows',slider),
       arrows = arrowsContainer.querySelectorAll('.arrow')

       arrows.forEach( function(arrow){
            arrow.addEventListener('click', function(e){
                e.preventDefault()
                pause()
                const clickedArrow = e.currentTarget

                // let y = 1===1 ? 5 : 6
                //clickedArrow.classList.contains('left') ? index-- : index++

                if(clickedArrow.classList.contains('left')) index--
                    else index++

                shiftSlide(index)
            })
       })
 
    }


    function setPuces(){

        const pucesContainer = document.createElement('div')
        pucesContainer.classList.add('puces-wrapper')

        const fragment = document.createDocumentFragment()
        for (let index = 0; index < slides.length; index++) {
            const div = document.createElement('div')
            div.classList.add('puce')
            if(index === 0) div.classList.add('active')
            div.dataset.index = index
            fragment.append(div)
        }

        

        pucesContainer.addEventListener('click', e =>{
            const clickedElement = e.target
            if( clickedElement.matches('.puce') ){
                pause()
                const indexNumber = Number(clickedElement.dataset.index)
                shiftSlide(indexNumber)
            }
        })

        pucesContainer.append(fragment)
        puces = pucesContainer.querySelectorAll('div')

        slider.append(pucesContainer)
    }

 
    





}





sliderFading({puces:true, autoplay:true})

